#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH
LANG=en_US.UTF-8

# panel offline upgrade script

panel_path='/www/server/panel'

if [ ! -d $panel_path ];then
	echo "Panel is not currently installed!"
	exit 0;
fi

base_dir=$(cd "$(dirname "$0")";pwd)
if [ $base_dir = $panel_path ];then
	echo "The offline upgrade command cannot be executed in the panel root directory!"
	exit 0;
fi

if [ ! -d $base_dir/class ];then
	echo "没有找到升级文件!"
	exit 0;
fi

rm -f $panel_path/*.pyc $panel_path/class/*.pyc
\cp -r -f $base_dir/. $panel_path/
/etc/init.d/bt restart
echo "===================================="
echo "Upgrade completed!"

